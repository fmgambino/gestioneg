<?php
/* tradução: ferreiramauricio.com */

$lang['cal_su']             = "Dom";
$lang['cal_mo']             = "Se";
$lang['cal_tu']             = "Te";
$lang['cal_we']             = "Qu";
$lang['cal_th']             = "Qu";
$lang['cal_fr']             = "Se";
$lang['cal_sa']             = "Sá";
$lang['cal_sun']        = "Dom";
$lang['cal_mon']        = "Lun";
$lang['cal_tue']        = "Mar";
$lang['cal_wed']        = "Mier";
$lang['cal_thu']        = "Juev";
$lang['cal_fri']        = "Vier";
$lang['cal_sat']        = "Sáb";
$lang['cal_sunday']         = "Domingo";
$lang['cal_monday']         = "Lunes";
$lang['cal_tuesday']    = "Martes";
$lang['cal_wednesday']  = "Miércoles";
$lang['cal_thursday']   = "Jueves";
$lang['cal_friday']         = "Viernes";
$lang['cal_saturday']   = "Sábado";
$lang['cal_jan']        = "Ene";
$lang['cal_feb']        = "Feb";
$lang['cal_mar']        = "Mar";
$lang['cal_apr']        = "Abr";
$lang['cal_may']        = "May";
$lang['cal_jun']        = "Jun";
$lang['cal_jul']        = "Jul";
$lang['cal_aug']        = "Ago";
$lang['cal_sep']        = "Set";
$lang['cal_oct']        = "Oct";
$lang['cal_nov']        = "Nov";
$lang['cal_dec']        = "Dic";
$lang['cal_january']    = "Janeiro";
$lang['cal_february']   = "FevereiroSQUI";
$lang['cal_march']      = "MarçoS";
$lang['cal_april']      = "Abril";
$lang['cal_mayl']       = "Maio";
$lang['cal_june']       = "Junho";
$lang['cal_july']       = "Julho";
$lang['cal_august']         = "Agosto";
$lang['cal_september']  = "Setembro";
$lang['cal_october']    = "Outubro";
$lang['cal_november']   = "Novembro";
$lang['cal_december']   = "Dezembro";


/* End of file calendar_lang.php */
/* Location: ./system/language/pt-br/calendar_lang.php */
