<table class="table table-bordered table-condensed">
    <tr>
        <td style="width: 180px">
            <img style="width: 150px;" src="<?=$em_logo?>">
        </td>

        <td>
            <b>Empresa: </b> <?=$em_nome?> <br>
            <b>CUIT/CUIL: </b> <?=$em_cnpj?><br>
            <b>Responsable: </b> <?=$res_nome?><br>
            <b>Fecha Inicial: </b> <?=$dataInicial?> <b>Fecha Final: </b> <?=$dataFinal?>

        </td>
    </tr>
</table>



