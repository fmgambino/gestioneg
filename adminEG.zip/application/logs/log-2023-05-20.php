<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-20 07:05:37 --> Config Class Initialized
INFO - 2023-05-20 07:05:37 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:05:37 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:05:37 --> Utf8 Class Initialized
INFO - 2023-05-20 07:05:37 --> URI Class Initialized
DEBUG - 2023-05-20 07:05:37 --> No URI present. Default controller set.
INFO - 2023-05-20 07:05:37 --> Router Class Initialized
INFO - 2023-05-20 07:05:37 --> Output Class Initialized
INFO - 2023-05-20 07:05:37 --> Security Class Initialized
DEBUG - 2023-05-20 07:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:05:37 --> Input Class Initialized
INFO - 2023-05-20 07:05:37 --> Language Class Initialized
INFO - 2023-05-20 07:05:37 --> Language Class Initialized
INFO - 2023-05-20 07:05:37 --> Config Class Initialized
INFO - 2023-05-20 07:05:37 --> Loader Class Initialized
INFO - 2023-05-20 07:05:37 --> Helper loaded: url_helper
INFO - 2023-05-20 07:05:37 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:05:37 --> Helper loaded: date_helper
INFO - 2023-05-20 07:05:37 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:05:37 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:05:37 --> Helper loaded: general_helper
INFO - 2023-05-20 07:05:53 --> Config Class Initialized
INFO - 2023-05-20 07:05:53 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:05:53 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:05:53 --> Utf8 Class Initialized
INFO - 2023-05-20 07:05:53 --> URI Class Initialized
DEBUG - 2023-05-20 07:05:53 --> No URI present. Default controller set.
INFO - 2023-05-20 07:05:53 --> Router Class Initialized
INFO - 2023-05-20 07:05:53 --> Output Class Initialized
INFO - 2023-05-20 07:05:53 --> Security Class Initialized
DEBUG - 2023-05-20 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:05:53 --> Input Class Initialized
INFO - 2023-05-20 07:05:53 --> Language Class Initialized
INFO - 2023-05-20 07:05:53 --> Language Class Initialized
INFO - 2023-05-20 07:05:53 --> Config Class Initialized
INFO - 2023-05-20 07:05:53 --> Loader Class Initialized
INFO - 2023-05-20 07:05:53 --> Helper loaded: url_helper
INFO - 2023-05-20 07:05:53 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:05:53 --> Helper loaded: date_helper
INFO - 2023-05-20 07:05:53 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:05:53 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:05:53 --> Helper loaded: general_helper
INFO - 2023-05-20 07:05:53 --> Database Driver Class Initialized
INFO - 2023-05-20 07:09:17 --> Config Class Initialized
INFO - 2023-05-20 07:09:17 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:09:17 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:09:17 --> Utf8 Class Initialized
INFO - 2023-05-20 07:09:17 --> URI Class Initialized
DEBUG - 2023-05-20 07:09:17 --> No URI present. Default controller set.
INFO - 2023-05-20 07:09:17 --> Router Class Initialized
INFO - 2023-05-20 07:09:17 --> Output Class Initialized
INFO - 2023-05-20 07:09:17 --> Security Class Initialized
DEBUG - 2023-05-20 07:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:09:17 --> Input Class Initialized
INFO - 2023-05-20 07:09:17 --> Language Class Initialized
INFO - 2023-05-20 07:09:17 --> Language Class Initialized
INFO - 2023-05-20 07:09:17 --> Config Class Initialized
INFO - 2023-05-20 07:09:17 --> Loader Class Initialized
INFO - 2023-05-20 07:09:17 --> Helper loaded: url_helper
INFO - 2023-05-20 07:09:17 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:09:17 --> Helper loaded: date_helper
INFO - 2023-05-20 07:09:17 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:09:17 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:09:17 --> Helper loaded: general_helper
INFO - 2023-05-20 07:09:17 --> Database Driver Class Initialized
INFO - 2023-05-20 07:09:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:09:17 --> Permission Class Initialized
INFO - 2023-05-20 07:09:17 --> Controller Class Initialized
INFO - 2023-05-20 07:09:18 --> Config Class Initialized
INFO - 2023-05-20 07:09:18 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:09:18 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:09:18 --> Utf8 Class Initialized
INFO - 2023-05-20 07:09:18 --> URI Class Initialized
INFO - 2023-05-20 07:09:18 --> Router Class Initialized
INFO - 2023-05-20 07:09:18 --> Output Class Initialized
INFO - 2023-05-20 07:09:18 --> Security Class Initialized
DEBUG - 2023-05-20 07:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:09:18 --> Input Class Initialized
INFO - 2023-05-20 07:09:18 --> Language Class Initialized
INFO - 2023-05-20 07:09:18 --> Language Class Initialized
INFO - 2023-05-20 07:09:18 --> Config Class Initialized
INFO - 2023-05-20 07:09:18 --> Loader Class Initialized
INFO - 2023-05-20 07:09:18 --> Helper loaded: url_helper
INFO - 2023-05-20 07:09:18 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:09:18 --> Helper loaded: date_helper
INFO - 2023-05-20 07:09:18 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:09:18 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:09:18 --> Helper loaded: general_helper
INFO - 2023-05-20 07:09:18 --> Database Driver Class Initialized
INFO - 2023-05-20 07:09:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:09:18 --> Permission Class Initialized
INFO - 2023-05-20 07:09:18 --> Controller Class Initialized
INFO - 2023-05-20 07:09:18 --> Model "Sgtos_model" initialized
DEBUG - 2023-05-20 04:09:18 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/sgtos/login.php
INFO - 2023-05-20 04:09:18 --> Final output sent to browser
DEBUG - 2023-05-20 04:09:18 --> Total execution time: 0.0247
INFO - 2023-05-20 07:09:42 --> Config Class Initialized
INFO - 2023-05-20 07:09:42 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:09:42 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:09:42 --> Utf8 Class Initialized
INFO - 2023-05-20 07:09:42 --> URI Class Initialized
INFO - 2023-05-20 07:09:42 --> Router Class Initialized
INFO - 2023-05-20 07:09:42 --> Output Class Initialized
INFO - 2023-05-20 07:09:42 --> Security Class Initialized
DEBUG - 2023-05-20 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:09:42 --> Input Class Initialized
INFO - 2023-05-20 07:09:42 --> Language Class Initialized
INFO - 2023-05-20 07:09:42 --> Language Class Initialized
INFO - 2023-05-20 07:09:42 --> Config Class Initialized
INFO - 2023-05-20 07:09:42 --> Loader Class Initialized
INFO - 2023-05-20 07:09:42 --> Helper loaded: url_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: date_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: general_helper
INFO - 2023-05-20 07:09:42 --> Database Driver Class Initialized
INFO - 2023-05-20 07:09:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:09:42 --> Permission Class Initialized
INFO - 2023-05-20 07:09:42 --> Controller Class Initialized
INFO - 2023-05-20 07:09:42 --> Model "Sgtos_model" initialized
INFO - 2023-05-20 07:09:42 --> Helper loaded: form_helper
INFO - 2023-05-20 07:09:42 --> Form Validation Class Initialized
INFO - 2023-05-20 07:09:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-20 07:09:42 --> Model "Audit_model" initialized
INFO - 2023-05-20 07:09:42 --> Config Class Initialized
INFO - 2023-05-20 07:09:42 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:09:42 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:09:42 --> Utf8 Class Initialized
INFO - 2023-05-20 07:09:42 --> URI Class Initialized
INFO - 2023-05-20 07:09:42 --> Router Class Initialized
INFO - 2023-05-20 07:09:42 --> Output Class Initialized
INFO - 2023-05-20 07:09:42 --> Security Class Initialized
DEBUG - 2023-05-20 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:09:42 --> Input Class Initialized
INFO - 2023-05-20 07:09:42 --> Language Class Initialized
INFO - 2023-05-20 07:09:42 --> Language Class Initialized
INFO - 2023-05-20 07:09:42 --> Config Class Initialized
INFO - 2023-05-20 07:09:42 --> Loader Class Initialized
INFO - 2023-05-20 07:09:42 --> Helper loaded: url_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: date_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:09:42 --> Helper loaded: general_helper
INFO - 2023-05-20 07:09:42 --> Database Driver Class Initialized
INFO - 2023-05-20 07:09:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:09:43 --> Permission Class Initialized
INFO - 2023-05-20 07:09:43 --> Controller Class Initialized
INFO - 2023-05-20 07:09:43 --> Model "Sgtos_model" initialized
DEBUG - 2023-05-20 04:09:43 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/topo.php
DEBUG - 2023-05-20 04:09:43 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/menu.php
DEBUG - 2023-05-20 04:09:43 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/sgtos/panel.php
DEBUG - 2023-05-20 04:09:43 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/conteudo.php
DEBUG - 2023-05-20 04:09:43 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/rodape.php
INFO - 2023-05-20 04:09:43 --> Final output sent to browser
DEBUG - 2023-05-20 04:09:43 --> Total execution time: 0.7157
INFO - 2023-05-20 07:09:44 --> Config Class Initialized
INFO - 2023-05-20 07:09:44 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:09:44 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:09:44 --> Utf8 Class Initialized
INFO - 2023-05-20 07:09:44 --> URI Class Initialized
INFO - 2023-05-20 07:09:44 --> Router Class Initialized
INFO - 2023-05-20 07:09:44 --> Output Class Initialized
INFO - 2023-05-20 07:09:44 --> Security Class Initialized
DEBUG - 2023-05-20 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:09:44 --> Input Class Initialized
INFO - 2023-05-20 07:09:44 --> Language Class Initialized
INFO - 2023-05-20 07:09:44 --> Language Class Initialized
INFO - 2023-05-20 07:09:44 --> Config Class Initialized
INFO - 2023-05-20 07:09:44 --> Loader Class Initialized
INFO - 2023-05-20 07:09:44 --> Helper loaded: url_helper
INFO - 2023-05-20 07:09:44 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:09:44 --> Helper loaded: date_helper
INFO - 2023-05-20 07:09:44 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:09:44 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:09:44 --> Helper loaded: general_helper
INFO - 2023-05-20 07:09:44 --> Database Driver Class Initialized
INFO - 2023-05-20 07:09:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:09:44 --> Permission Class Initialized
INFO - 2023-05-20 07:09:44 --> Controller Class Initialized
INFO - 2023-05-20 07:09:44 --> Model "Sgtos_model" initialized
INFO - 2023-05-20 07:09:44 --> Model "Os_model" initialized
INFO - 2023-05-20 07:09:44 --> Final output sent to browser
DEBUG - 2023-05-20 07:09:44 --> Total execution time: 0.1106
INFO - 2023-05-20 07:09:45 --> Config Class Initialized
INFO - 2023-05-20 07:09:45 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:09:45 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:09:45 --> Utf8 Class Initialized
INFO - 2023-05-20 07:09:45 --> URI Class Initialized
DEBUG - 2023-05-20 07:09:45 --> No URI present. Default controller set.
INFO - 2023-05-20 07:09:45 --> Router Class Initialized
INFO - 2023-05-20 07:09:45 --> Output Class Initialized
INFO - 2023-05-20 07:09:45 --> Security Class Initialized
DEBUG - 2023-05-20 07:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:09:45 --> Input Class Initialized
INFO - 2023-05-20 07:09:45 --> Language Class Initialized
INFO - 2023-05-20 07:09:45 --> Language Class Initialized
INFO - 2023-05-20 07:09:45 --> Config Class Initialized
INFO - 2023-05-20 07:09:45 --> Loader Class Initialized
INFO - 2023-05-20 07:09:45 --> Helper loaded: url_helper
INFO - 2023-05-20 07:09:45 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:09:45 --> Helper loaded: date_helper
INFO - 2023-05-20 07:09:45 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:09:45 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:09:45 --> Helper loaded: general_helper
INFO - 2023-05-20 07:09:45 --> Database Driver Class Initialized
INFO - 2023-05-20 07:09:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:09:45 --> Permission Class Initialized
INFO - 2023-05-20 07:09:45 --> Controller Class Initialized
INFO - 2023-05-20 07:09:45 --> Model "Sgtos_model" initialized
DEBUG - 2023-05-20 04:09:45 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/topo.php
DEBUG - 2023-05-20 04:09:45 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/menu.php
DEBUG - 2023-05-20 04:09:45 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/sgtos/panel.php
DEBUG - 2023-05-20 04:09:45 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/conteudo.php
DEBUG - 2023-05-20 04:09:45 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/rodape.php
INFO - 2023-05-20 04:09:45 --> Final output sent to browser
DEBUG - 2023-05-20 04:09:45 --> Total execution time: 0.0390
INFO - 2023-05-20 07:10:04 --> Config Class Initialized
INFO - 2023-05-20 07:10:04 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:10:04 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:10:04 --> Utf8 Class Initialized
INFO - 2023-05-20 07:10:04 --> URI Class Initialized
DEBUG - 2023-05-20 07:10:04 --> No URI present. Default controller set.
INFO - 2023-05-20 07:10:04 --> Router Class Initialized
INFO - 2023-05-20 07:10:04 --> Output Class Initialized
INFO - 2023-05-20 07:10:04 --> Security Class Initialized
DEBUG - 2023-05-20 07:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:10:04 --> Input Class Initialized
INFO - 2023-05-20 07:10:04 --> Language Class Initialized
INFO - 2023-05-20 07:10:04 --> Language Class Initialized
INFO - 2023-05-20 07:10:04 --> Config Class Initialized
INFO - 2023-05-20 07:10:04 --> Loader Class Initialized
INFO - 2023-05-20 07:10:04 --> Helper loaded: url_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: date_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: general_helper
INFO - 2023-05-20 07:10:04 --> Database Driver Class Initialized
INFO - 2023-05-20 07:10:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:10:04 --> Permission Class Initialized
INFO - 2023-05-20 07:10:04 --> Controller Class Initialized
INFO - 2023-05-20 07:10:04 --> Config Class Initialized
INFO - 2023-05-20 07:10:04 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:10:04 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:10:04 --> Utf8 Class Initialized
INFO - 2023-05-20 07:10:04 --> URI Class Initialized
INFO - 2023-05-20 07:10:04 --> Router Class Initialized
INFO - 2023-05-20 07:10:04 --> Output Class Initialized
INFO - 2023-05-20 07:10:04 --> Security Class Initialized
DEBUG - 2023-05-20 07:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:10:04 --> Input Class Initialized
INFO - 2023-05-20 07:10:04 --> Language Class Initialized
INFO - 2023-05-20 07:10:04 --> Language Class Initialized
INFO - 2023-05-20 07:10:04 --> Config Class Initialized
INFO - 2023-05-20 07:10:04 --> Loader Class Initialized
INFO - 2023-05-20 07:10:04 --> Helper loaded: url_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: date_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:10:04 --> Helper loaded: general_helper
INFO - 2023-05-20 07:10:04 --> Database Driver Class Initialized
INFO - 2023-05-20 07:10:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:10:04 --> Permission Class Initialized
INFO - 2023-05-20 07:10:04 --> Controller Class Initialized
INFO - 2023-05-20 07:10:04 --> Model "Sgtos_model" initialized
DEBUG - 2023-05-20 04:10:04 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/sgtos/login.php
INFO - 2023-05-20 04:10:04 --> Final output sent to browser
DEBUG - 2023-05-20 04:10:04 --> Total execution time: 0.0303
INFO - 2023-05-20 07:10:35 --> Config Class Initialized
INFO - 2023-05-20 07:10:35 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:10:35 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:10:35 --> Utf8 Class Initialized
INFO - 2023-05-20 07:10:35 --> URI Class Initialized
INFO - 2023-05-20 07:10:35 --> Router Class Initialized
INFO - 2023-05-20 07:10:35 --> Output Class Initialized
INFO - 2023-05-20 07:10:35 --> Security Class Initialized
DEBUG - 2023-05-20 07:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:10:35 --> Input Class Initialized
INFO - 2023-05-20 07:10:35 --> Language Class Initialized
INFO - 2023-05-20 07:10:35 --> Language Class Initialized
INFO - 2023-05-20 07:10:35 --> Config Class Initialized
INFO - 2023-05-20 07:10:35 --> Loader Class Initialized
INFO - 2023-05-20 07:10:35 --> Helper loaded: url_helper
INFO - 2023-05-20 07:10:35 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:10:35 --> Helper loaded: date_helper
INFO - 2023-05-20 07:10:35 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:10:35 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:10:35 --> Helper loaded: general_helper
INFO - 2023-05-20 07:10:35 --> Database Driver Class Initialized
INFO - 2023-05-20 07:10:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:10:35 --> Permission Class Initialized
INFO - 2023-05-20 07:10:35 --> Controller Class Initialized
INFO - 2023-05-20 07:10:35 --> Model "Sgtos_model" initialized
INFO - 2023-05-20 07:10:35 --> Helper loaded: form_helper
INFO - 2023-05-20 07:10:35 --> Form Validation Class Initialized
INFO - 2023-05-20 07:10:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-20 07:10:35 --> Model "Audit_model" initialized
INFO - 2023-05-20 07:10:36 --> Config Class Initialized
INFO - 2023-05-20 07:10:36 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:10:36 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:10:36 --> Utf8 Class Initialized
INFO - 2023-05-20 07:10:36 --> URI Class Initialized
INFO - 2023-05-20 07:10:36 --> Router Class Initialized
INFO - 2023-05-20 07:10:36 --> Output Class Initialized
INFO - 2023-05-20 07:10:36 --> Security Class Initialized
DEBUG - 2023-05-20 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:10:36 --> Input Class Initialized
INFO - 2023-05-20 07:10:36 --> Language Class Initialized
INFO - 2023-05-20 07:10:36 --> Language Class Initialized
INFO - 2023-05-20 07:10:36 --> Config Class Initialized
INFO - 2023-05-20 07:10:36 --> Loader Class Initialized
INFO - 2023-05-20 07:10:36 --> Helper loaded: url_helper
INFO - 2023-05-20 07:10:36 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:10:36 --> Helper loaded: date_helper
INFO - 2023-05-20 07:10:36 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:10:36 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:10:36 --> Helper loaded: general_helper
INFO - 2023-05-20 07:10:36 --> Database Driver Class Initialized
INFO - 2023-05-20 07:10:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:10:36 --> Permission Class Initialized
INFO - 2023-05-20 07:10:36 --> Controller Class Initialized
INFO - 2023-05-20 07:10:36 --> Model "Sgtos_model" initialized
DEBUG - 2023-05-20 04:10:36 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/topo.php
DEBUG - 2023-05-20 04:10:36 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/menu.php
DEBUG - 2023-05-20 04:10:36 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/sgtos/panel.php
DEBUG - 2023-05-20 04:10:36 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/conteudo.php
DEBUG - 2023-05-20 04:10:36 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/rodape.php
INFO - 2023-05-20 04:10:36 --> Final output sent to browser
DEBUG - 2023-05-20 04:10:36 --> Total execution time: 0.0362
INFO - 2023-05-20 07:10:39 --> Config Class Initialized
INFO - 2023-05-20 07:10:39 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:10:39 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:10:39 --> Utf8 Class Initialized
INFO - 2023-05-20 07:10:39 --> URI Class Initialized
INFO - 2023-05-20 07:10:39 --> Router Class Initialized
INFO - 2023-05-20 07:10:39 --> Output Class Initialized
INFO - 2023-05-20 07:10:39 --> Security Class Initialized
DEBUG - 2023-05-20 07:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:10:39 --> Input Class Initialized
INFO - 2023-05-20 07:10:39 --> Language Class Initialized
INFO - 2023-05-20 07:10:39 --> Language Class Initialized
INFO - 2023-05-20 07:10:39 --> Config Class Initialized
INFO - 2023-05-20 07:10:39 --> Loader Class Initialized
INFO - 2023-05-20 07:10:39 --> Helper loaded: url_helper
INFO - 2023-05-20 07:10:39 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:10:39 --> Helper loaded: date_helper
INFO - 2023-05-20 07:10:39 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:10:39 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:10:39 --> Helper loaded: general_helper
INFO - 2023-05-20 07:10:39 --> Database Driver Class Initialized
INFO - 2023-05-20 07:10:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:10:39 --> Permission Class Initialized
INFO - 2023-05-20 07:10:39 --> Controller Class Initialized
INFO - 2023-05-20 07:10:39 --> Model "Sgtos_model" initialized
INFO - 2023-05-20 07:10:39 --> Model "Os_model" initialized
INFO - 2023-05-20 07:10:39 --> Final output sent to browser
DEBUG - 2023-05-20 07:10:39 --> Total execution time: 0.0899
INFO - 2023-05-20 07:10:40 --> Config Class Initialized
INFO - 2023-05-20 07:10:40 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:10:40 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:10:40 --> Utf8 Class Initialized
INFO - 2023-05-20 07:10:40 --> URI Class Initialized
DEBUG - 2023-05-20 07:10:40 --> No URI present. Default controller set.
INFO - 2023-05-20 07:10:40 --> Router Class Initialized
INFO - 2023-05-20 07:10:40 --> Output Class Initialized
INFO - 2023-05-20 07:10:40 --> Security Class Initialized
DEBUG - 2023-05-20 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:10:40 --> Input Class Initialized
INFO - 2023-05-20 07:10:40 --> Language Class Initialized
INFO - 2023-05-20 07:10:40 --> Language Class Initialized
INFO - 2023-05-20 07:10:40 --> Config Class Initialized
INFO - 2023-05-20 07:10:40 --> Loader Class Initialized
INFO - 2023-05-20 07:10:40 --> Helper loaded: url_helper
INFO - 2023-05-20 07:10:40 --> Helper loaded: audit_helper
INFO - 2023-05-20 07:10:40 --> Helper loaded: date_helper
INFO - 2023-05-20 07:10:40 --> Helper loaded: dd_helper
INFO - 2023-05-20 07:10:40 --> Helper loaded: validation_helper
INFO - 2023-05-20 07:10:40 --> Helper loaded: general_helper
INFO - 2023-05-20 07:10:40 --> Database Driver Class Initialized
INFO - 2023-05-20 07:10:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2023-05-20 07:10:40 --> Permission Class Initialized
INFO - 2023-05-20 07:10:40 --> Controller Class Initialized
INFO - 2023-05-20 07:10:40 --> Model "Sgtos_model" initialized
DEBUG - 2023-05-20 04:10:40 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/topo.php
DEBUG - 2023-05-20 04:10:40 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/menu.php
DEBUG - 2023-05-20 04:10:40 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/sgtos/panel.php
DEBUG - 2023-05-20 04:10:40 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/conteudo.php
DEBUG - 2023-05-20 04:10:40 --> File loaded: /home/u197809344/domains/electronicagambino.com/public_html/admin/application/views/tema/rodape.php
INFO - 2023-05-20 04:10:40 --> Final output sent to browser
DEBUG - 2023-05-20 04:10:40 --> Total execution time: 0.0385
