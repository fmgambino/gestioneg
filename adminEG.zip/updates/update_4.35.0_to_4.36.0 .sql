ALTER TABLE usuarios ADD url_image_user varchar(255) NULL;
